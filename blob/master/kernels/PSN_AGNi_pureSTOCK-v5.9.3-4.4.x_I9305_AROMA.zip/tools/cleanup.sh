#!/sbin/busybox sh

rm -rf /tmp/packing
rm -rf /tmp/extracted
rm -rf /tmp/bootimg
rm -f /tmp/mkbootimg
rm -f /tmp/bootimgtools
rm -f /tmp/PSN_AGNi_builder.sh
rm -f /tmp/reseter.sh

