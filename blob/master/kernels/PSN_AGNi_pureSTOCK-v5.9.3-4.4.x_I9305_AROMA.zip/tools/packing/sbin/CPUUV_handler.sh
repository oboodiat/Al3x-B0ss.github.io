#!/sbin/busybox sh

###### AGNi CPUuv Rev. 2.0 #################
###### asv level based cpu uv ##############

/sbin/busybox sh /sbin/rootrw

ASV_LEVEL_LOG="/data/.AGNi/asv_level.txt"
ASV_LEVEL="`cat /sys/devices/system/cpu/cpu0/cpufreq/asv_level`"

touch $ASV_LEVEL_LOG
echo "$ASV_LEVEL" > $ASV_LEVEL_LOG

if [ "$ASV_LEVEL" == "ASV level: 0" ];
	then
	cp -rf /res/misc/asv0/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 1" ];
	then
	cp -rf /res/misc/asv1/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 2" ];
	then
	cp -rf /res/misc/asv2/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 3" ];
	then
	cp -rf /res/misc/asv3/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 4" ];
	then
	cp -rf /res/misc/asv4/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 5" ];
	then
	cp -rf /res/misc/asv5/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 6" ];
	then
	cp -rf /res/misc/asv6/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 7" ];
	then
	cp -rf /res/misc/asv7/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 8" ];
	then
	cp -rf /res/misc/asv8/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 9" ];
	then
	cp -rf /res/misc/asv9/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 10" ];
	then
	cp -rf /res/misc/asv10/* /res/scripts/
fi;
if [ "$ASV_LEVEL" == "ASV level: 11" ];
	then
	cp -rf /res/misc/asv11/* /res/scripts/
fi;
chmod 777 /res/scripts/S51enable_001bkcpuuv*
chmod 777 $ASV_LEVEL_LOG
/sbin/busybox sh /sbin/rootro

