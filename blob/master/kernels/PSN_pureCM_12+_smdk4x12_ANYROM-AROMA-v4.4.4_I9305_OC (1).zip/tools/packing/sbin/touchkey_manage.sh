#!/sbin/busybox sh

# HYBRID MODE AS DEFAULT
echo 2 > /sys/class/sec/sec_touchkey/touch_led_handling

