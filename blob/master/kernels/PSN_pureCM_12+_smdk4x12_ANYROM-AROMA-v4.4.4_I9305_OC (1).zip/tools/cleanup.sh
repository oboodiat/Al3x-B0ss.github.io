#!/sbin/busybox sh

rm -rf /tmp/packing
rm -rf /tmp/extracted
rm -rf /tmp/workboot
rm -rf /tmp/bootimg
rm -rf /tmp/oldboot
rm -f /tmp/mkbootimg
rm -f /tmp/unpack_bootimg
rm -f /tmp/bootimgtools
rm -f /tmp/PSN_AGNi_builder.sh
rm -f /tmp/reseter.sh

